from django.apps import AppConfig


class EmployeeRegisterConfig(AppConfig):
    name = 'employee_register'
